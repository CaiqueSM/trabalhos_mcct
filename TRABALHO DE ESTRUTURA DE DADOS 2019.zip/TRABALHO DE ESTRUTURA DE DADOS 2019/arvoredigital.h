#ifndef ARVOREDIGITAL_H_INCLUDED
#define ARVOREDIGITAL_H_INCLUDED



#endif // ARVOREDIGITAL_H_INCLUDED
class Node
{
public:
    Node();
    ~Node();
    int keyLeft;
    int keyRight;
    bool cheked;
    Node* left;
    Node* right;
};

class Tree
{
public:
    Tree();
    ~Tree();
    bool isEmpty();
    void createPermutation(int k);
    bool isCheked();
    void printTree();
    int numberNodes();
    int height;
private:
    Node* root;
    void visitNodes(Node* &n);
    void eraseNode(Node* &n);
    int countNodes(Node* n);
    Node* insertNodes(int n);
};
