#include <stdio.h>
#include "arvoredigital.h"
#include <math.h>
#include <stdlib.h>

using namespace std;

Node::Node()
{
    keyLeft = 0;
    keyRight = 0;
    cheked = false;
    left = 0;
    right = 0;
}

Node::~Node()
{
    keyLeft = 0;
    keyRight = 1;
    left=0;
    right=0;
}

Tree::Tree()
{
    root = 0;
    height = 0;
}

Tree::~Tree()
{
    eraseNode(root);
}

void Tree::eraseNode(Node* &n)
{
    if(n!=0)
    {
        eraseNode(n->left);
        eraseNode(n->right);
        delete n;
        n=0;
    }
}

bool Tree::isEmpty(){return root==0;}

void Tree::createPermutation(int n)
{
    root = insertNodes(n);
}

Node* Tree::insertNodes(int n)
{
    Node* pt;
    int nleft, nright;

    if(n == 0)
    {
        return 0;
    }
    else
    {
        nleft = n/2;
        nright = n-nleft-1;
        pt = new Node();
        pt->keyLeft = 0;
        pt->keyRight = 1;
        pt->left = insertNodes(nleft);
        pt->right = insertNodes(nright);
        return pt;
    }
}

bool Tree::isCheked()
{
    return root->cheked;
}

void Tree::printTree()
{
    visitNodes(root);
}

void Tree::visitNodes(Node* &pt)
{
    int i = 0;
    Node* aux = pt;
    int *way = (int*)malloc(height*sizeof(int*));

    while (aux->left!= 0)
    {
        if(!aux->left->cheked)
        {
            way[i] = aux->keyLeft;
            i = i+1;
            aux = aux->left;
        }else break;
    }
    if(aux->left == 0)
    {
        aux->cheked = true;
    }

    while(aux->right != 0)
    {
        if(!aux->right->cheked)
        {
            if((aux->left!= 0) && (!aux->left->cheked))
            {
                way[i] = aux->keyLeft;
                i = i + 1;
                aux = aux->left;
            }else{
                way[i] = aux->keyRight;
                i = i+1;
                aux = aux->right;
            }
        }else break;
    }
    if(aux->right == 0)
    {
        aux->cheked = true;
    }

    if((aux->left!= 0)&&(aux->right!=0))
    {
        if(aux->left->cheked && aux->right->cheked)
        {
            aux->cheked = true;
            return;
        }
    }
    if((aux->left == 0)&&(aux->right ==0))
    {
        for(i = 0; i<height; i++)
        {
            printf("%d", way[i]);
        }
        printf("\n");
    }
    free(way);
}

int Tree::countNodes(Node* n)
{
    if(n==0)
        return 0;

    return 1+ countNodes(n->left) + countNodes(n->right);
}

int Tree::numberNodes()
{
    return countNodes(root);
}

int main(int argc, char** argv )
{
    int numNo, k, i;
    Tree* t1=new Tree();
    printf("Entre com o numero de bits:\n");
    scanf("%d", &k);
    t1->height = k;
    numNo = pow(2,k+1) - 1;
    t1->createPermutation(numNo);
    printf("Todas as permuta��es de c�digos de k d�gitos deste alfabeto s�o:\n");
    while(!t1->isCheked())
    {
        t1->printTree();
    }
    delete t1;
}
